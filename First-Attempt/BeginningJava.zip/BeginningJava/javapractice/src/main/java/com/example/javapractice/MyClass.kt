package com.example.javapractice

class MyClass {
}