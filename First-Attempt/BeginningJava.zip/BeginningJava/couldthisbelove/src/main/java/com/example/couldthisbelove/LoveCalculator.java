package com.example.couldthisbelove;

import java.util.Random;

public class LoveCalculator {
    public static void main(String[] args) {

        System.out.println("Your love score is: " + ifYouHadMyLove("Candy", "Candiee  "));
    }

    public static int ifYouHadMyLove(String yourName, String theirName){
        Random randObject = new Random();
        int loveScore = randObject.nextInt(101);
        if(loveScore>80){
            System.out.println(yourName+ "and " +theirName+ "Love each other very much ");
        }
        else if(loveScore>40){
            System.out.println(yourName+ "and " +theirName+ "Love like coke and memtos ");
        }
        else {
            System.out.println(yourName+ "and " +theirName+ "Don't Love each other ");
        }
        return loveScore;
    }
}