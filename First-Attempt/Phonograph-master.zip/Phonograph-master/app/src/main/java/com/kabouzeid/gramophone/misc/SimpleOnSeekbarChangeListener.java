package com.kabouzeid.gramophone.misc;

import android.widget.SeekBar;

/**
 * @author Karim Abou Zeid (kabouzeid)
 */
public abstract class SimpleOnSeekbarChangeListener implements SeekBar.OnSeekBarChangeListener {
    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}
